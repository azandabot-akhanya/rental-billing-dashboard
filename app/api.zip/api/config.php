<?php
// CORS is handled in index.php - do not duplicate headers here

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Database {
    private $host = "197.242.150.197";
    private $db_name = "thynkxv8r6h8_thynkxpro";
    private $username = "thynkxv8r6h8_admin";
    private $password = "wesleyc@123";
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            http_response_code(500);
            echo json_encode(["message" => "Database connection failed: " . $exception->getMessage()]);
            exit;
        }

        return $this->conn;
    }
}
?>